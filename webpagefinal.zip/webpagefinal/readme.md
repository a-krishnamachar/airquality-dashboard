Master's Project | Aditya Krishnamachar

Webpages consulted:
https://geoffboeing.com/2015/10/exporting-python-data-geojson/
https://gist.github.com/jfreels/6733593
https://www.d3-graph-gallery.com/
https://docs.mapbox.com
